package com.rentme.productseller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.rentme.productseller.Database.CartDbHelper;

import java.util.ArrayList;

public class ProductDetailActivity extends AppCompatActivity {

    ProductModel productModel;

    DatabaseReference mDatabaseForProductUploading;



    private TextView Category_Name_View;
    TextView productName, productPrice, productDisc;
    ImageView productImage;
    Button AddToCart,home;
    ProgressDialog progressDialog;

//    ArrayList<ReviewModel> list = new ArrayList<>();
//    ReviewAdapter reviewAdapter;


//    private RecyclerView reviewsrecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);


        productModel = (ProductModel) getIntent().getSerializableExtra("Product");


        Category_Name_View = findViewById(R.id.Category_View_Id);
        Category_Name_View.setText(productModel.getCategory());

//        reviewsrecyclerView = findViewById(R.id.reviews);
//        reviewsrecyclerView.setLayoutManager(new LinearLayoutManager(this));
//        reviewAdapter = new ReviewAdapter(list,ProductDetailPage.this);
//        reviewsrecyclerView.setAdapter(reviewAdapter);


        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ProductDetailActivity.this,MainActivity.class));
                finish();
            }
        });



        initViews();

//        GetReviews(productModel.getProductId());

    }


    private void initViews() {

//        mDatabaseForProductUploading = FirebaseDatabase.getInstance().getReference().child("Categories").child(productModel.getCatId()).child("Products");


//        Selected_Category_ID = productModel.getCatId();
//        Selected_Category_Name = productModel.getCatName();

        progressDialog = new ProgressDialog(this);

        productName = findViewById(R.id.product_name_edit_add);
        productName.setText(productModel.getTitle());
        productDisc = findViewById(R.id.product_disc_edit_add);
        productDisc.setText(productModel.getDescription());
        productImage = findViewById(R.id.product_image_add);
        productPrice = findViewById(R.id.actual_price);
        productPrice.setText(productModel.getPrice()+" $$");

        Glide.with(this).load(productModel.getImage()).into(productImage);
//        productImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                CropImage.activity()
//                        .setAspectRatio(1, 1)
//                        .start(ProductDetailPage.this);
//            }
//        });
        AddToCart = findViewById(R.id.add_product_btn);
        AddToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                add_toCardDialog(productModel);


            }
        });


    }
    int number = 1;

    private void add_toCardDialog(final ProductModel model) {

        AlertDialog.Builder builder1 = new AlertDialog.Builder(this);
        //setting up the layout for alert dialog
        View view1 = LayoutInflater.from(this).inflate(R.layout.add_to_cart_dialog, null, false);

        builder1.setView(view1);

        TextView foodDisc = view1.findViewById(R.id.food_disc_dialog);
        foodDisc.setText(model.getDescription());

        TextView foodName = view1.findViewById(R.id.food_name_dialog);
        foodName.setText(model.getTitle());
        TextView foodPrice = view1.findViewById(R.id.food_price_food_dialog);
        foodPrice.setText(  model.getPrice() + " $$");
        ImageView foodImage = view1.findViewById(R.id.food_image_add_card_dialog);
        Glide.with(ProductDetailActivity.this).load(model.getImage()).into(foodImage);
        final TextView quantity_text = view1.findViewById(R.id.quantity_text);
        ImageView addBtn = view1.findViewById(R.id.add_quantity);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number++;
                quantity_text.setText(String.valueOf(number));
            }
        });

        ImageView minusBtn = view1.findViewById(R.id.remove_quantity);
        Button addToCartBtn = view1.findViewById(R.id.add_toCartFinal);
        Button cancelBtn = view1.findViewById(R.id.cancel_btn_dialog);

        final AlertDialog dialogg = builder1.create();
        dialogg.show();

        cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = 1;
                dialogg.cancel();
            }
        });

        minusBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int ne = number--;
                if (ne <= 1) {
                    number++;
                } else {
                    quantity_text.setText(String.valueOf(number));
                }
            }
        });

        addToCartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addToCart(model);
                dialogg.dismiss();


            }
        });
    }

    private void addToCart(ProductModel model) {
        CartProductModel cartProductModel = new CartProductModel();

        cartProductModel.setProductId(model.getId());
        cartProductModel.setProductName(model.getTitle());
        cartProductModel.setProductImage(model.getImage());
        cartProductModel.setProductDiscription(model.getDescription());
        cartProductModel.setProductPrice(model.getPrice());
        cartProductModel.setCatName(model.getCategory());
        cartProductModel.setQuantity(number);


        CartDbHelper dbHelper = new CartDbHelper(ProductDetailActivity.this);
        double response = dbHelper.insertItem(cartProductModel);
        if (response == -1) {
            Toast.makeText(ProductDetailActivity.this, "Not Added", Toast.LENGTH_LONG).show();
        } else {


            Toast.makeText(ProductDetailActivity.this, "Added to Cart.", Toast.LENGTH_LONG).show();
        }
    }
    public void onClickBackItem(View view) {
        onBackPressed();


    }

}